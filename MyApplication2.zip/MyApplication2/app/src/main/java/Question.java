public class Question {

    public Question(String myQuestion, String myAnswer) {
        MyQuestion = myQuestion;
        MyAnswer = myAnswer;
    }

    private String MyQuestion;
    private String MyAnswer;

    public String getMyQuestion() {
        return MyQuestion;
    }

    public String getMyAnswer() {
        return MyAnswer;
    }

    public void setMyQuestion(String myQuestion) {
        MyQuestion = myQuestion;
    }

    public void setMyAnswer(String myAnswer) {
        MyAnswer = myAnswer;
    }

}
