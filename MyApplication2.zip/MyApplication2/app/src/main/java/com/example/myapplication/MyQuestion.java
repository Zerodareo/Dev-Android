package com.example.myapplication;

public class MyQuestion {
    public MyQuestion(String s, String s1) {
    }
}
