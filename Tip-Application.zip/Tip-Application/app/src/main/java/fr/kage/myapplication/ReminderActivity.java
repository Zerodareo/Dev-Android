package fr.kage.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ReminderActivity extends AppCompatActivity {

    private Button mButtonAddReminder;
    private Button mButtonDeleteReminder;
    private TextView mTextReminderCount;

    private int mReminderCount;

    public static List res;

    public static final String EXTRA_REMINDER_COUNT = "fr.applicationderappels.extra.REMINDER_COUNT";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminders);

        mButtonAddReminder = findViewById(R.id.button_add_reminder);
        mButtonDeleteReminder = findViewById(R.id.button_delete_reminder);
        mTextReminderCount = findViewById(R.id.text_reminder_count);

        Intent intent = getIntent();
        mReminderCount = intent.getIntExtra(fr.kage.myapplication.MainActivity.EXTRA_REMINDER_COUNT, 0);

        mTextReminderCount.setText(String.valueOf(mReminderCount));

        ListView liste = (ListView) findViewById(R.id.liste);
        res = new ArrayList<Tache>();
        if(!(res.size() == 0)){
            liste.setAdapter(new TacheAdapter(this, R.layout.design_listview, res));
        }

        mButtonAddReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddReminder.class);
                startActivityForResult(intent, 98);
                mReminderCount++;
                mTextReminderCount.setText(String.valueOf(mReminderCount));
            }
        });

        mButtonDeleteReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mReminderCount > 0) {
                    mReminderCount--;
                    mTextReminderCount.setText(String.valueOf(mReminderCount));
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra(EXTRA_REMINDER_COUNT, mReminderCount);
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);



        if (requestCode == 98 && resultCode == RESULT_OK) {
            Tache tache = new Tache();
            if(data.hasExtra("add_titre")){
                tache.setTitreTache(data.getStringExtra("get_titre"));
            }
            if(data.hasExtra("add_date")){
                tache.setDateTache(data.getStringExtra("add_date"));
            }
            if(data.hasExtra("add_heure")){
                tache.setHeureTache(data.getStringExtra("add_heure"));
            }
            if(data.hasExtra("add_descr")){
                tache.setDescriptionTache(data.getStringExtra("add_descr"));
            }
            res.add(tache);
        }


    }
}