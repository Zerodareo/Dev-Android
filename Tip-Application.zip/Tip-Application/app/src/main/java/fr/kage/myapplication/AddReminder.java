package fr.kage.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class AddReminder extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_reminder);

        TextView titre = (TextView) findViewById(R.id.titre);
        TextView date = (TextView) findViewById(R.id.date);
        TextView heure = (TextView) findViewById(R.id.heure);
        TextView descr = (TextView) findViewById(R.id.descr);
        Button valider = (Button) findViewById(R.id.valider);

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String get_titre = titre.getText().toString();
                String get_date = date.getText().toString();
                String get_heure = heure.getText().toString();
                String get_descr = descr.getText().toString();

                Intent intent = new Intent(getApplicationContext(), ReminderActivity.class);
                intent.putExtra("add_titre", (CharSequence) get_titre);
                intent.putExtra("add_date", (CharSequence) get_date);
                intent.putExtra("add_heure", (CharSequence) get_heure);
                intent.putExtra("add_descr", (CharSequence) get_descr);
                startActivity(intent);
            }
        });
    }
}



