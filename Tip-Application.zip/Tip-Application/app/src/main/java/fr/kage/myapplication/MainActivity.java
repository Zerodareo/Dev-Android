package fr.kage.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText mEditName;
    private Button mButton;
    private TextView mTextWelcome;

    private int mReminderCount;

    private SharedPreferences mPreferences;
    private String sharedPrefFile =
            "com.example.android.reminderapp";

    public static final String EXTRA_REMINDER_COUNT = "com.example.android.reminderapp.extra.REMINDER_COUNT";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mEditName = findViewById(R.id.editTextName);
        mButton = findViewById(R.id.buttonSubmit);
        mTextWelcome = findViewById(R.id.text_welcome);

        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);

        String name = mPreferences.getString("name", "");
        mReminderCount = mPreferences.getInt("count", 0);

        if (!name.equals("")) {
            String welcomeMessage = String.format(getString(R.string.welcome_back), name);
            mTextWelcome.setText(welcomeMessage);
        }

        mButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("StringFormatInvalid")
            @Override
            public void onClick(View view) {
                String name = mEditName.getText().toString();
                mTextWelcome.setText(getString(R.string.welcome, name));

                SharedPreferences.Editor preferencesEditor = mPreferences.edit();
                preferencesEditor.putString("name", name);
                preferencesEditor.apply();

                Intent intent = new Intent(MainActivity.this, ReminderActivity.class);
                intent.putExtra(EXTRA_REMINDER_COUNT, mReminderCount);
                startActivityForResult(intent, 1);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();

        SharedPreferences.Editor preferencesEditor = mPreferences.edit();
        preferencesEditor.putInt("count", mReminderCount);
        preferencesEditor.apply();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            mReminderCount = data.getIntExtra(ReminderActivity.EXTRA_REMINDER_COUNT, 0);
        }
    }
}

