package fr.kage.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.HashMap;
import java.util.List;

public class TacheAdapter extends ArrayAdapter<Tache> {

    HashMap<Integer, Tache> listmap = new HashMap<Integer, Tache>();
    int viewID;
    Context mContext;

    public TacheAdapter(@NonNull Context context, int resource, @NonNull List<Tache> objects) {
        super(context, resource, objects);

        mContext = context;
        viewID = resource;
        for (int i = 0; i < objects.size(); ++i){
            listmap.put(i, objects.get(i));
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(viewID, parent, false);
        TextView titre_tache = (TextView) rowView.findViewById(R.id.titre_tache);
        TextView titre_date = (TextView) rowView.findViewById(R.id.date_tache);
        TextView titre_heure = (TextView) rowView.findViewById(R.id.heure_tache);
        TextView btn_supprimer = (TextView) rowView.findViewById(R.id.supprimer_tache);

        Tache tache = listmap.get(Integer.valueOf(position));

        titre_tache.setText(tache.getTitreTache());
        titre_date.setText(tache.getDateTache());
        titre_heure.setText(tache.getHeureTache());

        btn_supprimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tache.setSupprimer(true);
            }
        });

        /*if (tache.isSupprimer()){
            return null;
        }*/

        return rowView;
    }
}
