package fr.kage.myapplication;

public class Tache {
    private String titreTache;
    private String heureTache;
    private String dateTache;

    public String getDescriptionTache() {
        return descriptionTache;
    }

    public void setDescriptionTache(String descriptionTache) {
        this.descriptionTache = descriptionTache;
    }

    private String descriptionTache;
    private boolean supprimer = false;

    public boolean isSupprimer() {
        return supprimer;
    }

    public Tache(){

    }

    public Tache(String titreTache, String heureTache, String dateTache, String descriptionTache) {
        this.titreTache = titreTache;
        this.heureTache = heureTache;
        this.dateTache = dateTache;
        this.descriptionTache = descriptionTache;
    }

    public void setSupprimer(boolean supprimer) {
        this.supprimer = supprimer;
    }

    public String getTitreTache() {
        return titreTache;
    }

    public void setTitreTache(String titreTache) {
        this.titreTache = titreTache;
    }

    public String getHeureTache() {
        return heureTache;
    }

    public void setHeureTache(String heureTache) {
        this.heureTache = heureTache;
    }

    public String getDateTache() {
        return dateTache;
    }

    public void setDateTache(String dateTache) {
        this.dateTache = dateTache;
    }
}
